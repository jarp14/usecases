## After the automatic generation of the graphical editor using Eugenia, replace the following icons:

org.chico.usecases.diagram/icons/obj16/UsecasesDiagramFile.gif
org.chico.usecases.diagram/icons/wizban/NewUsecasesWizard.gif
org.chico.usecases.edit/icons/full/obj16/*.gif
org.chico.usecases.editor/icons/full/obj16/UsecasesModelFile.gif
org.chico.usecases.editor/icons/full/wizban/NewUsecases.gif

* = nodes and links 